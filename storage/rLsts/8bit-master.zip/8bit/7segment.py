#!/bin/python3
filename = "7segment.bin"
code = bytearray([0x00] * 2048)

digits = ( 0x7e, 0x30, 0x6d, 0x79, 0x33, 0x5b, 0x5f, 0x70, 0x7f, 0x7b )

# ONE'S COMPLEMENT
for x in range(0, 256):
	code[x] = digits[int(x % 10)]
	code[x + 256] = digits[int((x / 10) % 10)]
	code[x + (256 * 2)] = digits[int((x / 100) % 10)]
	code[x + (256 * 3)] = 0x00


# TWO'S COMPLEMENT
for x in range(-128, 128):
	address = 256 + x if x < 0 else x
	code[address + (256 * 4)] = digits[abs(x) % 10]
	code[address + (256 * 5)] = digits[int((abs(x) / 10) % 10)]
	code[address + (256 * 6)] = digits[int((abs(x) / 100) % 10)]
	code[address + (256 * 7)] = (0x01 if x < 0 else 0x00)

with open(filename, "wb") as out_file:
	out_file.write(code)
