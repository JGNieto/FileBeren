#!/bin/python3
# ------- FILE INITIALIZATION ------- #
filename = "program-with-flags-4bit.bin"
code = bytearray([0x00] * 8192)

# TODO: ror & rol (hardware based)

# ------- CONSTANT DEFINITION ------- #
HLT = 0b0000000100000000 # Halt
MI  = 0b0000001000000000 # Memory Adress Register IN
RI  = 0b0000010000000000 # RAM In
RO  = 0b0000100000000000 # RAM Out
NXT = 0b0001000000000000 # NEXT (viva la gentuza)
II  = 0b0010000000000000 # Instruction Register In
AI  = 0b0100000000000000 # A Register In
AO  = 0b1000000000000000 # A Register Out
#       12345678
EO  = 0b0000000000000001 # ALU / Sum Out (Se supone que la E es Sigma)
SU  = 0b0000000000000010 # Subtract
BI  = 0b0000000000000100 # B Register In
OI  = 0b0000000000001000 # Output Register In
CE  = 0b0000000000010000 # Counter Enable / Increment
CO  = 0b0000000000100000 # Counter Out
J   = 0b0000000001000000 # Program Counter In (Jump)
FI  = 0b0000000010000000 # Flags In

#FLAGS:
FLAGS_NONE = 0
FLAGS_C = 1
FLAGS_Z = 2

JC = 7 # JUMP CARRY POSITION IN uCODE
JZ = 8 # JUMP ZERO POSITION IN uCODE

# ------- TEMPLATE INITIALIZATION ------- #
UCODE_TEMPLATE = [
  [ CO|MI,  RO|II|CE,  0,      0,        0,     0,           0, 0 ],   # 0000 - NOP
  [ CO|MI,  RO|II|CE,  CO|MI,  CE|RO|MI, RO|AI, 0,           0, 0 ],   # 0001 - LDA
  [ CO|MI,  RO|II|CE,  CO|MI,  CE|RO|MI, RO|BI, EO|AI|FI,    0, 0 ],   # 0010 - ADD
  [ CO|MI,  RO|II|CE,  CO|MI,  CE|RO|MI, RO|BI, EO|AI|SU|FI, 0, 0 ],   # 0011 - SUB
  [ CO|MI,  RO|II|CE,  CO|MI,  CE|RO|MI, AO|RI, 0,           0, 0 ],   # 0100 - STA
  [ CO|MI,  RO|II|CE,  CO|MI,  RO|AI|CE, 0,     0,           0, 0 ],   # 0101 - LDI
  [ CO|MI,  RO|II|CE,  CO|MI,  RO|J|CE,  0,     0,           0, 0 ],   # 0110 - JMP
  [ CO|MI,  RO|II|CE,  0,      0,        0,     0,           0, 0 ],   # 0111 - JC
  [ CO|MI,  RO|II|CE,  0,      0,        0,     0,           0, 0 ],   # 1000 - JZ
  [ CO|MI,  RO|II|CE,  0,      0,        0,     0,           0, 0 ],   # 1001
  [ CO|MI,  RO|II|CE,  0,      0,        0,     0,           0, 0 ],   # 1010
  [ CO|MI,  RO|II|CE,  0,      0,        0,     0,           0, 0 ],   # 1011
  [ CO|MI,  RO|II|CE,  0,      0,        0,     0,           0, 0 ],   # 1100
  [ CO|MI,  RO|II|CE,  0,      0,        0,     0,           0, 0 ],   # 1101
  [ CO|MI,  RO|II|CE,  AO|OI,  0,        0,     0,           0, 0 ],   # 1110 - OUT
  [ CO|MI,  RO|II|CE,  HLT, HLT, HLT, HLT, HLT, HLT               ],   # 1111 - HLT
]

# ------- MICROCODE CREATION ------- #
ucode = [ [ [ 0 for i in range(8) ] for j in range(16)] for k in range(4) ]

# ------- CONDITIONAL JUMP SUPPORT ------- #
# WHEN NO FLAGS, NO JUMPS
ucode[FLAGS_NONE] = UCODE_TEMPLATE

# WHEN ZERO FLAG, JUMP IN "JZ"
ucode[FLAGS_C]        = UCODE_TEMPLATE
ucode[FLAGS_C][JC][2] = CO|MI
ucode[FLAGS_C][JC][3] = RO|J|CE

# WHEN CARRY FLAG, JUMP IN "JC"
ucode[FLAGS_Z]        = UCODE_TEMPLATE
ucode[FLAGS_Z][JZ][2] = CO|MI
ucode[FLAGS_Z][JZ][3] = RO|J|CE

# WHEN BOTH FLAGS, BOTH JUMPS
ucode[FLAGS_C + FLAGS_Z]        = UCODE_TEMPLATE
ucode[FLAGS_C + FLAGS_Z][JC][2] = CO|MI
ucode[FLAGS_C + FLAGS_Z][JC][3] = RO|J|CE
ucode[FLAGS_C + FLAGS_Z][JZ][2] = CO|MI
ucode[FLAGS_C + FLAGS_Z][JZ][3] = RO|J|CE

# Analyse what would be the situation during a running program for every address in the EEPROM (that we care about).
for address in range(1024):
    flags       = (address & 0b1100000000) >> 8
    byte_sel    = (address & 0b0010000000) >> 7
    instruction = (address & 0b0001111000) >> 3
    step        = (address & 0b0000000111)
    insert      = ucode[flags][instruction][step]

    # For ease of read purposes, the NXT instruction has been replaced by a 0 in the uCode, and has to be replaced back.
    if insert == 0: insert = NXT

    code[address] = insert & 0b11111111 if byte_sel else insert >> 8

# ------- FILE WRITING ------- #
with open(filename, "wb") as out_file:
	out_file.write(code)
